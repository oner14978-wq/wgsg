/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.ui.screens.content.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.movtery.zalithlauncher.R
import com.movtery.zalithlauncher.game.version.installed.Version
import com.movtery.zalithlauncher.game.version.installed.VersionsManager
import com.movtery.zalithlauncher.setting.AllSettings
import com.movtery.zalithlauncher.setting.unit.min
import com.movtery.zalithlauncher.ui.screens.content.elements.VersionIconImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Paleta fixa da nova Home (reproduz a imagem de referência) */
private object HomePalette {
    val Background = Color(0xFF0B0A14)
    val Sidebar = Color(0xFF0F0D1C)
    val Card = Color(0xFF181229)
    val CardBorder = Color(0xFF2E2250)
    val Purple = Color(0xFF7B2FFF)
    val PurpleSoft = Color(0xFFB57BFF)
    val Pink = Color(0xFFE879F9)
    val Text = Color(0xFFFFFFFF)
    val TextSoft = Color(0xFFB9B0D6)
    val Green = Color(0xFF22C55E)
    val Amber = Color(0xFFFBBF24)
}

/** Ações reais da Home, ligadas ao sistema de navegação e ao launcher */
class HomeDashboardActions(
    val onLaunch: (Version) -> Unit,
    val onEditInstance: (Version) -> Unit,
    val onInstances: () -> Unit,
    val onMods: () -> Unit,
    val onShaders: () -> Unit,
    val onResourcePacks: () -> Unit,
    val onServers: () -> Unit,
    val onSettings: () -> Unit,
    val onAccounts: () -> Unit,
    val onDownload: () -> Unit,
    val onNotifications: () -> Unit,
    val onOpenNews: () -> Unit
)

@Composable
fun HomeDashboard(
    actions: HomeDashboardActions,
    modifier: Modifier = Modifier
) {
    val version by VersionsManager.currentVersion.collectAsStateWithLifecycle()
    val isRefreshing by VersionsManager.isRefreshing.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(HomePalette.Background)
    ) {
        HomeHeader(actions = actions)

        Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
            HomeSidebar(actions = actions)

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(start = 12.dp, end = 12.dp, bottom = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                HomeBanner(modifier = Modifier.weight(1f))
                HomeQuickCards(actions = actions, version = version, isRefreshing = isRefreshing)
                HomeBottomSection(actions = actions, version = version, isRefreshing = isRefreshing)
            }
        }

        HomeStatusBar(version = version, isRefreshing = isRefreshing)
    }
}

// ---------------------------------------------------------------- Barra lateral

@Composable
private fun HomeSidebar(actions: HomeDashboardActions) {
    Column(
        modifier = Modifier
            .width(84.dp)
            .fillMaxHeight()
            .background(HomePalette.Sidebar)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        SidebarItem("Início", R.drawable.ic_home_filled, selected = true, onClick = {})
        SidebarItem("Instâncias", R.drawable.ic_package_2_outlined, onClick = actions.onInstances)
        SidebarItem("Mods", R.drawable.ic_extension_outlined, onClick = actions.onMods)
        SidebarItem("Shaders", R.drawable.ic_home_shaders, onClick = actions.onShaders)
        SidebarItem("Pacotes de Recursos", R.drawable.ic_folder_zip_outlined, onClick = actions.onResourcePacks)
        SidebarItem("Servidores", R.drawable.ic_dns_outlined, onClick = actions.onServers)
        SidebarItem("Configurações", R.drawable.ic_settings_filled, onClick = actions.onSettings)
    }
}

@Composable
private fun SidebarItem(
    label: String,
    icon: Int,
    onClick: () -> Unit,
    selected: Boolean = false
) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (selected) {
                    Modifier.shadow(
                        elevation = 14.dp,
                        shape = shape,
                        ambientColor = HomePalette.Purple,
                        spotColor = HomePalette.Purple
                    )
                } else Modifier
            )
            .clip(shape)
            .background(if (selected) HomePalette.Purple else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Icon(
            painter = painterResource(icon),
            contentDescription = label,
            tint = if (selected) Color.White else HomePalette.TextSoft,
            modifier = Modifier.size(24.dp)
        )
        Text(
            text = label,
            color = if (selected) Color.White else HomePalette.TextSoft,
            fontSize = 11.sp,
            lineHeight = 12.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

// ---------------------------------------------------------------- Cabeçalho

@Composable
private fun HomeHeader(actions: HomeDashboardActions) {
    var menuOpen by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(68.dp)
            .padding(start = 14.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(R.drawable.img_home_creeper),
            contentDescription = null,
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(14.dp))
        )
        Spacer(modifier = Modifier.width(22.dp))
        Column {
            Text(
                text = "Minecraft",
                color = HomePalette.Text,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                lineHeight = 22.sp
            )
            Text(
                text = "Java Edition",
                color = HomePalette.PurpleSoft,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 16.sp
            )
        }
        Spacer(modifier = Modifier.weight(1f))

        IconButton(onClick = actions.onNotifications) {
            Icon(painterResource(R.drawable.ic_home_bell), "Notificações", tint = HomePalette.Text)
        }
        IconButton(onClick = actions.onSettings) {
            Icon(painterResource(R.drawable.ic_settings_filled), "Configurações", tint = HomePalette.Text)
        }
        Box {
            IconButton(onClick = { menuOpen = true }) {
                Icon(painterResource(R.drawable.ic_more_vert), "Menu", tint = HomePalette.Text)
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text("Contas") },
                    onClick = { menuOpen = false; actions.onAccounts() }
                )
                DropdownMenuItem(
                    text = { Text("Baixar versões") },
                    onClick = { menuOpen = false; actions.onDownload() }
                )
                DropdownMenuItem(
                    text = { Text("Instâncias") },
                    onClick = { menuOpen = false; actions.onInstances() }
                )
                DropdownMenuItem(
                    text = { Text("Configurações") },
                    onClick = { menuOpen = false; actions.onSettings() }
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Banner

@Composable
private fun HomeBanner(modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(24.dp)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .border(1.dp, HomePalette.CardBorder, shape)
    ) {
        Image(
            painter = painterResource(R.drawable.img_home_banner),
            contentDescription = "Minecraft Java Edition",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alignment = Alignment.Center
        )
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            repeat(4) { index ->
                Box(
                    modifier = Modifier
                        .size(if (index == 0) 10.dp else 8.dp)
                        .clip(CircleShape)
                        .background(if (index == 0) HomePalette.Pink else Color(0x66FFFFFF))
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Cartões rápidos

@Composable
private fun HomeQuickCards(
    actions: HomeDashboardActions,
    version: Version?,
    isRefreshing: Boolean
) {
    val launchable = version?.takeIf { !isRefreshing && it.isValid() }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(68.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        QuickCard(
            modifier = Modifier.weight(1f),
            title = "Jogar",
            subtitle = "Inicie o Minecraft com seus mods!",
            highlighted = true,
            leading = {
                Image(
                    painter = painterResource(R.drawable.img_home_grass),
                    contentDescription = null,
                    modifier = Modifier.size(40.dp)
                )
            },
            onClick = { launchable?.let(actions.onLaunch) ?: actions.onInstances() }
        )
        QuickCard(
            modifier = Modifier.weight(1f),
            title = "Mods",
            subtitle = "Adicione mods facilmente!",
            leading = { QuickIcon(R.drawable.ic_extension_outlined) },
            onClick = actions.onMods
        )
        QuickCard(
            modifier = Modifier.weight(1f),
            title = "Shaders",
            subtitle = "Deixe seu jogo mais bonito!",
            leading = { QuickIcon(R.drawable.ic_home_shaders) },
            onClick = actions.onShaders
        )
        QuickCard(
            modifier = Modifier.weight(1f),
            title = "Texturas",
            subtitle = "Personalize seu mundo!",
            leading = { QuickIcon(R.drawable.ic_folder_zip_outlined) },
            onClick = actions.onResourcePacks
        )
    }
}

@Composable
private fun QuickIcon(icon: Int) {
    Icon(
        painter = painterResource(icon),
        contentDescription = null,
        tint = HomePalette.PurpleSoft,
        modifier = Modifier.size(34.dp)
    )
}

@Composable
private fun QuickCard(
    title: String,
    subtitle: String,
    leading: @Composable () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    highlighted: Boolean = false
) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        modifier = modifier
            .fillMaxHeight()
            .then(
                if (highlighted) {
                    Modifier.shadow(
                        elevation = 14.dp,
                        shape = shape,
                        ambientColor = HomePalette.Purple,
                        spotColor = HomePalette.Purple
                    )
                } else Modifier
            )
            .clip(shape)
            .background(
                if (highlighted) {
                    Brush.linearGradient(listOf(Color(0xFF3B1494), Color(0xFF5B1FD0)))
                } else {
                    Brush.linearGradient(listOf(HomePalette.Card, HomePalette.Card))
                }
            )
            .border(
                BorderStroke(if (highlighted) 1.5.dp else 1.dp, if (highlighted) HomePalette.Purple else HomePalette.CardBorder),
                shape
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        leading()
        Spacer(modifier = Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = HomePalette.Text,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Text(
                text = subtitle,
                color = HomePalette.TextSoft,
                fontSize = 10.sp,
                lineHeight = 12.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
        Icon(
            painter = painterResource(R.drawable.ic_keyboard_arrow_right),
            contentDescription = null,
            tint = HomePalette.Text,
            modifier = Modifier.size(20.dp)
        )
    }
}

// ---------------------------------------------------------------- Instâncias + Notícias

@Composable
private fun HomeBottomSection(
    actions: HomeDashboardActions,
    version: Version?,
    isRefreshing: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(112.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        InstancesCard(
            modifier = Modifier
                .weight(1.15f)
                .fillMaxHeight(),
            actions = actions,
            version = version,
            isRefreshing = isRefreshing
        )
        NewsCard(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            actions = actions
        )
    }
}

@Composable
private fun SectionCard(
    modifier: Modifier,
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier = modifier
            .clip(shape)
            .background(HomePalette.Card)
            .border(1.dp, HomePalette.CardBorder, shape)
            .padding(10.dp)
    ) {
        content()
    }
}

@Composable
private fun SectionHeader(
    icon: Int,
    iconTint: Color,
    title: String,
    link: String,
    onLink: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(painterResource(icon), null, tint = iconTint, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = title,
            color = HomePalette.PurpleSoft,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f)
        )
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable(onClick = onLink)
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = link, color = HomePalette.TextSoft, fontSize = 11.sp)
            Icon(
                painterResource(R.drawable.ic_keyboard_arrow_right),
                null,
                tint = HomePalette.TextSoft,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
private fun InstancesCard(
    modifier: Modifier,
    actions: HomeDashboardActions,
    version: Version?,
    isRefreshing: Boolean
) {
    var menuOpen by remember { mutableStateOf(false) }

    //quantidade real de mods (.jar) na pasta mods da instância
    val modsCount by produceState(initialValue = 0, key1 = version) {
        value = version?.let { current ->
            withContext(Dispatchers.IO) {
                runCatching {
                    File(current.getGameDir(), "mods")
                        .listFiles { file -> file.isFile && file.name.endsWith(".jar") }
                        ?.size ?: 0
                }.getOrDefault(0)
            }
        } ?: 0
    }

    SectionCard(modifier = modifier) {
        SectionHeader(
            icon = R.drawable.ic_star_filled,
            iconTint = HomePalette.Pink,
            title = "Suas Instâncias",
            link = "Ver todas",
            onLink = actions.onInstances
        )
        Spacer(modifier = Modifier.height(6.dp))

        val valid = version?.takeIf { !isRefreshing && it.isValid() }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(14.dp))
                .background(HomePalette.Background.copy(alpha = 0.6f))
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (valid == null) {
                Text(
                    text = if (isRefreshing) "Carregando instâncias…" else "Nenhuma instância pronta",
                    color = HomePalette.TextSoft,
                    fontSize = 13.sp,
                    modifier = Modifier.weight(1f)
                )
                HomeSmallButton(R.drawable.ic_package_2_outlined, "Instâncias", actions.onInstances)
            } else {
                VersionIconImage(version = valid, modifier = Modifier.size(44.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = valid.getVersionName(),
                        color = HomePalette.Text,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${valid.getVersionSummary()} • $modsCount Mods",
                        color = HomePalette.TextSoft,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(HomePalette.Purple)
                        .clickable { actions.onLaunch(valid) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painterResource(R.drawable.ic_play_arrow_filled),
                        "Jogar",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                IconButton(onClick = { actions.onEditInstance(valid) }) {
                    Icon(painterResource(R.drawable.ic_edit_filled), "Editar", tint = HomePalette.TextSoft)
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(painterResource(R.drawable.ic_more_vert), "Opções", tint = HomePalette.TextSoft)
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Configurações da instância") },
                            onClick = { menuOpen = false; actions.onEditInstance(valid) }
                        )
                        DropdownMenuItem(
                            text = { Text("Mods") },
                            onClick = { menuOpen = false; actions.onMods() }
                        )
                        DropdownMenuItem(
                            text = { Text("Todas as instâncias") },
                            onClick = { menuOpen = false; actions.onInstances() }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeSmallButton(icon: Int, description: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(HomePalette.Purple)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(painterResource(icon), description, tint = Color.White, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun NewsCard(
    modifier: Modifier,
    actions: HomeDashboardActions
) {
    SectionCard(modifier = modifier) {
        SectionHeader(
            icon = R.drawable.ic_public,
            iconTint = HomePalette.Amber,
            title = "Notícias",
            link = "Ver mais",
            onLink = actions.onOpenNews
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(14.dp))
                .clickable(onClick = actions.onOpenNews),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(R.drawable.img_home_news),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxHeight()
                    .width(120.dp)
                    .clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Notícias do Minecraft",
                    color = HomePalette.Text,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "minecraft.net",
                    color = HomePalette.PurpleSoft,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Barra de status

@Composable
private fun HomeStatusBar(version: Version?, isRefreshing: Boolean) {
    val ready = !isRefreshing && version?.isValid() == true
    val ram = AllSettings.ramAllocation.state ?: AllSettings.ramAllocation.min

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(38.dp)
            .background(HomePalette.Sidebar)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(if (ready) HomePalette.Green else HomePalette.Amber)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = when {
                isRefreshing -> "Carregando instâncias…"
                ready -> "Pronto para jogar!"
                else -> "Nenhuma instância selecionada"
            },
            color = HomePalette.Text,
            fontSize = 13.sp
        )
        Spacer(modifier = Modifier.weight(1f))
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(Color(0xFF3B1494))
                .border(1.dp, HomePalette.Purple, RoundedCornerShape(50))
                .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                painterResource(R.drawable.ic_home_memory),
                null,
                tint = HomePalette.PurpleSoft,
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(text = "RAM: $ram MB", color = HomePalette.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(modifier = Modifier.width(14.dp))
        Icon(
            painterResource(R.drawable.ic_home_phone),
            null,
            tint = HomePalette.TextSoft,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = "Android", color = HomePalette.TextSoft, fontSize = 12.sp)
    }
}
