/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.ui.components

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import kotlin.math.roundToInt

@Composable
fun FloatingBall(
    position: Offset,
    onPositionChanged: (Offset) -> Unit,
    modifier: Modifier = Modifier,
    onSavePos: () -> Unit = {},
    onClick: () -> Unit = {},
    alpha: Float = 1f,
    color: Color = Color.Black.copy(alpha = 0.25f),
    contentColor: Color = Color.White.copy(alpha = 0.95f),
    shape: Shape = MaterialTheme.shapes.medium,
    content: @Composable () -> Unit
) {
    var ballSize by remember { mutableStateOf(IntSize.Zero) }
    val currentPosition by rememberUpdatedState(position)
    val currentOnClick by rememberUpdatedState(onClick)
    val currentOnSavePos by rememberUpdatedState(onSavePos)

    var dragging by remember { mutableStateOf(false) }
    var dragPosition by remember { mutableStateOf(Offset.Zero) }

    //在首次启动时，将悬浮球放到屏幕的 TopCenter
    //确保这个行为只触发一次
    var isInitialized by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) { isInitialized = true }

    //检查是否是RTL布局，需要做初始位置适配
    val isRtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    BoxWithConstraints(
        modifier = Modifier
            .alpha(alpha)
            .fillMaxSize()
            .onSizeChanged { size ->
                if (currentPosition != Offset.Zero) {
                    val maxX = (size.width - ballSize.width).toFloat().coerceAtLeast(0f)
                    val maxY = (size.height - ballSize.height).toFloat().coerceAtLeast(0f)

                    val newX = currentPosition.x.coerceIn(0f, maxX)
                    val newY = currentPosition.y.coerceIn(0f, maxY)

                    if (newX != currentPosition.x || newY != currentPosition.y) {
                        onPositionChanged(Offset(newX, newY))
                    }
                }
            }
    ) {
        val parentWidth by rememberUpdatedState(constraints.maxWidth)
        val parentHeight by rememberUpdatedState(constraints.maxHeight)

        Surface(
            modifier = Modifier
                .onSizeChanged { size ->
                    ballSize = size
                    if (isInitialized || currentPosition != Offset.Zero) return@onSizeChanged
                    val x = ((parentWidth - ballSize.width) / 2f) //默认位置 TopCenter
                    val positionX = x.coerceIn(0f, (parentWidth - ballSize.width).toFloat())
                    val positionY = 0f.coerceIn(0f, (parentHeight - ballSize.height).toFloat())
                    onPositionChanged(Offset(positionX, positionY))
                }
                .offset {
                    val renderPosition = if (dragging) dragPosition else currentPosition
                    val maxX = (parentWidth - ballSize.width).coerceAtLeast(0)
                    val maxY = (parentHeight - ballSize.height).coerceAtLeast(0)
                    IntOffset(
                        renderPosition.x.roundToInt().coerceIn(0, maxX),
                        renderPosition.y.roundToInt().coerceIn(0, maxY)
                    )
                }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)

                        val startPosition = down.position
                        var isDragging = false

                        val clampedX = currentPosition.x
                            .coerceIn(0f, (parentWidth - ballSize.width).toFloat().coerceAtLeast(0f))
                        val clampedY = currentPosition.y
                            .coerceIn(0f, (parentHeight - ballSize.height).toFloat().coerceAtLeast(0f))
                        if (clampedX != currentPosition.x || clampedY != currentPosition.y) {
                            onPositionChanged(Offset(clampedX, clampedY))
                        }

                        //drag 返回 false 表示手势被取消，此时不触发点击与保存
                        val completed = drag(down.id) { change ->
                            val delta = change.positionChange()
                            val distanceFromStart = (change.position - startPosition).getDistance()

                            if (!isDragging && distanceFromStart > viewConfiguration.touchSlop) {
                                //超出了拖动检测距离，说明是真的在进行拖动
                                //标记当前为拖动，避免松开手指后，判定为点击事件
                                isDragging = true
                                dragging = true
                                dragPosition = Offset(clampedX, clampedY)
                            }

                            if (isDragging) { //只有在拖动的情况下，才会变更位置
                                val deltaX = if (isRtl) -delta.x else delta.x
                                val newX = dragPosition.x + deltaX
                                val newY = dragPosition.y + delta.y
                                dragPosition = Offset(
                                    newX.coerceIn(0f, (parentWidth - ballSize.width).toFloat()),
                                    newY.coerceIn(0f, (parentHeight - ballSize.height).toFloat())
                                )
                            }
                            change.consume()
                        }

                        val upConsumed = if (completed) {
                            //复核抬起事件是否已被上层消费
                            awaitPointerEvent(PointerEventPass.Final)
                                .changes.firstOrNull { it.id == down.id }?.isConsumed ?: true
                        } else {
                            true
                        }
                        if (isDragging) {
                            //拖动结束才一次性同步位置
                            onPositionChanged(dragPosition)
                            if (!upConsumed) {
                                currentOnSavePos()
                            }
                            dragging = false
                        } else if (!upConsumed) {
                            //非拖动事件，判定为一次点击
                            currentOnClick()
                        }
                    }
                }.then(modifier),
            color = color,
            contentColor = contentColor,
            shape = shape
        ) {
            content()
        }
    }
}