/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.ui.screens.content.download.game.neon

import com.movtery.zalithlauncher.game.versioninfo.MinecraftVersion

/** Textos exibidos no cartão de uma versão. */
internal data class NeonVersionText(
    val typeLabel: String,
    val title: String,
    val description: String,
    val compat: String
)

private val RELEASE_NAMES = mapOf(
    "1.21.9" to "Copper Age",
    "1.21.10" to "Copper Age",
    "1.21.8" to "Chase the Skies",
    "1.21.7" to "Chase the Skies",
    "1.21.6" to "Chase the Skies",
    "1.21.5" to "Spring to Life",
    "1.21.4" to "The Garden Awakens",
    "1.21.3" to "Bundles of Bravery",
    "1.21.2" to "Bundles of Bravery",
    "1.21" to "Tricky Trials",
    "1.20" to "Trails & Tales",
    "1.19" to "The Wild Update",
    "1.18" to "Caves & Cliffs: Parte II",
    "1.17" to "Caves & Cliffs: Parte I",
    "1.16" to "Nether Update",
    "1.15" to "Buzzy Bees",
    "1.14" to "Village & Pillage",
    "1.13" to "Update Aquatic",
    "1.12" to "World of Color",
    "1.11" to "Exploration Update",
    "1.10" to "Frostburn Update",
    "1.9" to "Combat Update",
    "1.8" to "Bountiful Update",
    "1.7" to "The Update that Changed the World",
    "1.6" to "Horse Update",
    "1.5" to "Redstone Update",
    "1.4" to "Pretty Scary Update",
)

private fun releaseName(id: String): String? {
    val base = id.takeWhile { it.isDigit() || it == '.' }.trimEnd('.')
    RELEASE_NAMES[base]?.let { return it }
    val parts = base.split('.')
    if (parts.size >= 2) RELEASE_NAMES["${parts[0]}.${parts[1]}"]?.let { return it }
    return null
}

/** "2025-10-07T12:00:00+00:00" -> "07/10/2025" */
private fun brDate(releaseTime: String): String {
    val d = releaseTime.take(10).split('-')
    return if (d.size == 3) "${d[2]}/${d[1]}/${d[0]}" else releaseTime
}

/** Versão do Java exigida pela versão do jogo (pela data de lançamento / esquema de nome). */
internal fun neonJavaVersion(version: MinecraftVersion): Int {
    val id = version.version.id
    val first = id.takeWhile { it.isDigit() }.toIntOrNull()
    if (first != null && first >= 26) return 25
    val date = version.version.releaseTime.take(10)
    return when {
        date >= "2024-03-27" -> 21
        date >= "2021-05-12" -> 17
        else -> 8
    }
}

internal fun neonVersionText(version: MinecraftVersion): NeonVersionText {
    val id = version.version.id
    val year = version.version.releaseTime.take(4)
    val date = brDate(version.version.releaseTime)
    val compat = "Java ${neonJavaVersion(version)} · Android"

    return when (version.type) {
        MinecraftVersion.Type.Release -> {
            val name = releaseName(id)
            NeonVersionText(
                typeLabel = "Release",
                title = name ?: "Minecraft Java Edition",
                description = "Versão estável com todos os recursos da atualização. Lançada em $date.",
                compat = compat
            )
        }
        MinecraftVersion.Type.Snapshot -> NeonVersionText(
            typeLabel = "Snapshot",
            title = "Versão de testes",
            description = "Prévia com recursos em desenvolvimento, de $date. Pode ser instável.",
            compat = compat
        )
        MinecraftVersion.Type.AprilFools -> NeonVersionText(
            typeLabel = "1º de abril",
            title = "Edição especial",
            description = "Versão de brincadeira lançada em $date. Feita só para diversão.",
            compat = compat
        )
        MinecraftVersion.Type.OldBeta -> NeonVersionText(
            typeLabel = "Beta",
            title = "Beta clássico",
            description = "O Minecraft Beta de $year, antes da versão 1.0. Experiência nostálgica.",
            compat = compat
        )
        MinecraftVersion.Type.OldAlpha -> NeonVersionText(
            typeLabel = "Alpha",
            title = "Alpha original",
            description = "O Minecraft Alpha de $year. Uma viagem às origens do jogo.",
            compat = compat
        )
        else -> NeonVersionText(
            typeLabel = "Versão",
            title = "Minecraft",
            description = "Versão de $date.",
            compat = compat
        )
    }
}
