/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.ui.screens.content.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.movtery.zalithlauncher.game.renderer.RendererInterface
import com.movtery.zalithlauncher.game.renderer.Renderers
import com.movtery.zalithlauncher.setting.AllSettings
import com.movtery.zalithlauncher.utils.device.checkVulkanSupport
import com.movtery.zalithlauncher.utils.isAdrenoGPU

/**
 * Informações de exibição de um renderizador embutido no launcher.
 * Tudo aqui descreve renderizadores que realmente existem no projeto (com bibliotecas no jniLibs).
 */
private data class RendererInfo(
    val api: String,
    val description: String,
    val compatibility: String,
    val needsVulkan: Boolean = false,
    val adrenoOnly: Boolean = false,
    val maliOnly: Boolean = false
)

private val rendererInfoById: Map<String, RendererInfo> = mapOf(
    // Krypton Wrapper (NG-GL4ES)
    "e7b90ed6-e518-4d4e-93dc-5c7133cd5b31" to RendererInfo(
        api = "OpenGL → OpenGL ES 3",
        description = "Evolução do GL4ES, com foco em desempenho e compatibilidade com as versões mais novas do jogo.",
        compatibility = "Recomendado para a maioria dos aparelhos"
    ),
    // GL4ES
    "8b52d82d-8f6d-4d3a-a767-dc93f8b72fc7" to RendererInfo(
        api = "OpenGL 2.1 → OpenGL ES 2",
        description = "Tradutor leve e muito compatível. Boa opção para aparelhos mais fracos.",
        compatibility = "Versões antigas até a 1.21.4"
    ),
    // Kopper Zink
    "0fa435e2-46df-45c9-906c-b29606aaef00" to RendererInfo(
        api = "OpenGL sobre Vulkan (Mesa Zink)",
        description = "Executa o OpenGL do jogo em cima do Vulkan do aparelho. Pode render mais em GPUs com bom driver Vulkan.",
        compatibility = "Exige suporte a Vulkan",
        needsVulkan = true
    ),
    // MobileGlues
    "acaf8100-bbaf-4d68-b30d-38bf42fcd640" to RendererInfo(
        api = "OpenGL 4.0 → OpenGL ES 3",
        description = "Traduz OpenGL 4.0 para OpenGL ES, com suporte maior a recursos modernos e a shaders.",
        compatibility = "Aparelhos com OpenGL ES 3.x"
    ),
    // VirGL
    "a3ccc1fe-de3f-4a81-8c45-2485181b63b3" to RendererInfo(
        api = "OpenGL (Mesa/VirGL)",
        description = "Renderização via Mesa com VirGL. Muito compatível, porém costuma ter desempenho menor.",
        compatibility = "Funciona na maioria dos aparelhos"
    ),
    // Freedreno
    "1ad7249f-5784-4f00-bc72-174b3578ee46" to RendererInfo(
        api = "OpenGL (Mesa Gallium)",
        description = "Driver Mesa Freedreno para GPUs Qualcomm Adreno.",
        compatibility = "Somente GPUs Adreno",
        adrenoOnly = true
    ),
    // Panfrost
    "9b2808c4-11af-4c72-a9c6-94c940396475" to RendererInfo(
        api = "OpenGL (Mesa Gallium)",
        description = "Driver Mesa Panfrost para GPUs ARM Mali.",
        compatibility = "Somente GPUs Mali, versões até a 1.21.4",
        maliOnly = true
    )
)

/**
 * Seção moderna de seleção de renderizadores: um cartão por renderizador,
 * com API gráfica, descrição, compatibilidade, avisos e seleção salva em [AllSettings.renderer].
 */
@Composable
fun RendererPickerSection(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val vulkanSupported = remember(context) { checkVulkanSupport(context.packageManager) }
    val adreno = remember { runCatching { isAdrenoGPU() }.getOrDefault(false) }
    val selectedId = AllSettings.renderer.state
    val renderers = Renderers.getRenderers()

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Renderizadores",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            modifier = Modifier.alpha(0.75f),
            text = "Escolha como o Minecraft Java desenha os gráficos. A escolha é salva e usada na próxima vez que o jogo iniciar.",
            style = MaterialTheme.typography.bodyMedium
        )

        renderers.forEach { renderer ->
            RendererPickerCard(
                renderer = renderer,
                info = rendererInfoById[renderer.getUniqueIdentifier()],
                selected = renderer.getUniqueIdentifier() == selectedId,
                vulkanSupported = vulkanSupported,
                adreno = adreno,
                onSelect = { AllSettings.renderer.save(renderer.getUniqueIdentifier()) }
            )
        }

        Text(
            modifier = Modifier.alpha(0.7f),
            text = "Holy GL4ES e LTW não estão incluídos neste projeto (não há biblioteca .so correspondente). " +
                "Renderizadores adicionais podem ser instalados como plugin pelo botão de download abaixo e aparecerão nesta lista.",
            style = MaterialTheme.typography.labelMedium
        )
    }
}

@Composable
private fun RendererPickerCard(
    renderer: RendererInterface,
    info: RendererInfo?,
    selected: Boolean,
    vulkanSupported: Boolean,
    adreno: Boolean,
    onSelect: () -> Unit
) {
    val shape = RoundedCornerShape(24.dp)
    val colors = MaterialTheme.colorScheme
    val container = if (selected) colors.primaryContainer else colors.surfaceContainerHigh
    val borderColor = if (selected) colors.primary else colors.outlineVariant

    val warnings = buildList {
        if (info?.needsVulkan == true && !vulkanSupported) {
            add("Este aparelho não informa suporte a Vulkan; o renderizador provavelmente não vai iniciar.")
        }
        if (info?.adrenoOnly == true && !adreno) {
            add("Requer GPU Adreno (Qualcomm); este aparelho não parece usar uma.")
        }
        if (info?.maliOnly == true) {
            add("Requer GPU Mali. Não é possível detectar isso automaticamente; use somente se o aparelho tiver Mali.")
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(container)
            .border(width = if (selected) 2.dp else 1.dp, color = borderColor, shape = shape)
            .clickable(onClick = onSelect)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = renderer.getRendererName(),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            if (selected) {
                RendererChip(text = "Selecionado", background = colors.primary, content = colors.onPrimary)
            }
        }

        Text(
            text = info?.description ?: renderer.getRendererSummary() ?: "Renderizador instalado como plugin.",
            style = MaterialTheme.typography.bodyMedium
        )

        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            RendererChip(
                text = "API: ${info?.api ?: "OpenGL"}",
                background = colors.secondaryContainer,
                content = colors.onSecondaryContainer
            )
            info?.let {
                RendererChip(
                    text = it.compatibility,
                    background = colors.secondaryContainer,
                    content = colors.onSecondaryContainer
                )
            }
            val minVer = renderer.getDisplayMinMCVersion()
            val maxVer = renderer.getDisplayMaxMCVersion()
            if (minVer != null || maxVer != null) {
                val range = buildString {
                    append("Minecraft ")
                    minVer?.let { append(">= $it") }
                    if (minVer != null && maxVer != null) append("  ")
                    maxVer?.let { append("<= $it") }
                }
                RendererChip(text = range, background = colors.tertiaryContainer, content = colors.onTertiaryContainer)
            }
        }

        warnings.forEach { warning ->
            RendererChip(text = "⚠ $warning", background = colors.errorContainer, content = colors.onErrorContainer)
        }
    }
}

@Composable
private fun RendererChip(text: String, background: Color, content: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(background)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text = text, style = MaterialTheme.typography.labelMedium, color = content)
    }
}
