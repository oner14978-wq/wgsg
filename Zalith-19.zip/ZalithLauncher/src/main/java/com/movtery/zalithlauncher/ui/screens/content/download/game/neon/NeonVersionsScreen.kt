/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.ui.screens.content.download.game.neon

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import coil3.compose.SubcomposeAsyncImage
import com.movtery.zalithlauncher.R
import com.movtery.zalithlauncher.game.download.game.neon.NeonDownloadManager
import com.movtery.zalithlauncher.game.download.game.neon.NeonVersionArt
import com.movtery.zalithlauncher.game.version.installed.Version
import com.movtery.zalithlauncher.game.version.installed.VersionsManager
import com.movtery.zalithlauncher.game.versioninfo.MinecraftVersion
import com.movtery.zalithlauncher.game.versioninfo.MinecraftVersions
import com.movtery.zalithlauncher.ui.components.SimpleAlertDialog
import com.movtery.zalithlauncher.utils.file.formatFileSize
import com.movtery.zalithlauncher.utils.network.isUsingMobileData
import com.movtery.zalithlauncher.viewmodel.EventViewModel
import com.movtery.zalithlauncher.viewmodel.sendKeepScreen
import kotlin.math.PI
import kotlin.math.sin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

//region Paleta neon
private val NeonBg = Color(0xFF07040F)
private val NeonBg2 = Color(0xFF150A2E)
private val NeonPurple = Color(0xFF9D4EFF)
private val NeonViolet = Color(0xFFC77DFF)
private val NeonPink = Color(0xFFFF4FD8)
private val NeonCard = Color(0xFF170E2E)
private val NeonGreen = Color(0xFF3DDC84)
private val NeonRed = Color(0xFFFF5470)
private val NeonDim = Color(0xFFB9A8D9)

private val PurpleBrush = Brush.horizontalGradient(listOf(Color(0xFF7B2FFF), Color(0xFFB44DFF)))
private val GreenBrush = Brush.horizontalGradient(listOf(Color(0xFF1FA85B), Color(0xFF3DDC84)))
private val RedBrush = Brush.horizontalGradient(listOf(Color(0xFFC0264A), Color(0xFFFF5470)))
private val GhostBrush = Brush.horizontalGradient(listOf(Color(0xFF2A1A4D), Color(0xFF3A2468)))

/** Fase (0..1) compartilhada por todas as animações contínuas da tela. */
private val LocalNeonPhase = staticCompositionLocalOf<State<Float>> { mutableStateOf(0f) }
//endregion

private enum class NeonCategory(val label: String, val glyph: String) {
    Recent("Recentes", "★"),
    Old("Antigas", "◷"),
    Beta("Beta", "β"),
    Snapshot("Snapshot", "◎"),
    Cobook("Cobook", "❖")
}

private sealed interface NeonState {
    data object Loading : NeonState
    data class Ready(val versions: List<MinecraftVersion>) : NeonState
    data class Failure(val message: String) : NeonState
}

private class NeonVersionsViewModel : ViewModel() {
    var state by mutableStateOf<NeonState>(NeonState.Loading)
        private set
    var category by mutableStateOf(NeonCategory.Recent)
        private set

    fun select(value: NeonCategory) {
        category = value
    }

    fun load(force: Boolean = false) {
        viewModelScope.launch {
            state = NeonState.Loading
            state = runCatching {
                MinecraftVersions.refreshVersions(force)
                NeonState.Ready(MinecraftVersions.allVersions.value)
            }.getOrElse { e ->
                NeonState.Failure(e.localizedMessage ?: e.message ?: "Erro desconhecido")
            }
        }
        viewModelScope.launch { NeonVersionArt.load(force) }
    }

    init {
        load()
    }
}

/**
 * Tela completa de seleção de versões (visual neon roxo).
 *
 * @param onCustomize abre o fluxo original de personalização (nome, Fabric, Forge, OptiFine...)
 */
@Composable
fun NeonVersionsScreen(
    isVisible: Boolean,
    eventViewModel: EventViewModel,
    onCustomize: (MinecraftVersion) -> Unit
) {
    val vm = viewModel(key = "NeonVersionsViewModel") { NeonVersionsViewModel() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val downloads by NeonDownloadManager.items.collectAsStateWithLifecycle()
    val installedList by VersionsManager.versions.collectAsStateWithLifecycle()
    val artMap by NeonVersionArt.images.collectAsStateWithLifecycle()
    val installedByName = remember(installedList) { installedList.associateBy { it.getVersionName() } }

    var pendingMobile by remember { mutableStateOf<String?>(null) }
    var pendingUninstall by remember { mutableStateOf<Version?>(null) }

    //mantém a tela acesa enquanto algo está baixando
    val hasActive = downloads.values.any {
        it.status == NeonDownloadManager.Status.Downloading || it.status == NeonDownloadManager.Status.Queued
    }
    LaunchedEffect(hasActive) { eventViewModel.sendKeepScreen(hasActive) }
    DisposableEffect(Unit) { onDispose { eventViewModel.sendKeepScreen(false) } }

    fun requestInstall(id: String) {
        if (isUsingMobileData(context)) pendingMobile = id
        else NeonDownloadManager.start(context, id)
    }

    val transition = rememberInfiniteTransition(label = "neonPhase")
    val phase = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3200, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )
    val enter by animateFloatAsState(if (isVisible) 1f else 0f, tween(450), label = "enter")

    CompositionLocalProvider(LocalNeonPhase provides phase) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = enter; translationY = (1f - enter) * 40f }
                .neonBackground()
        ) {
            Column(Modifier.fillMaxSize()) {
                NeonHeader(
                    category = vm.category,
                    onSelect = { vm.select(it) },
                    onRefresh = { vm.load(force = true) }
                )

                when (val state = vm.state) {
                    is NeonState.Loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { NeonSpinner() }

                    is NeonState.Failure -> Column(
                        Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Não foi possível carregar as versões",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(state.message, color = NeonDim, fontSize = 12.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(14.dp))
                        NeonButton(
                            text = "Tentar novamente",
                            onClick = { vm.load(force = true) },
                            modifier = Modifier.width(220.dp)
                        )
                    }

                    is NeonState.Ready -> {
                        val sorted = remember(state.versions) {
                            state.versions.sortedByDescending { it.version.releaseTime }
                        }
                        val releases = remember(sorted) {
                            sorted.filter { it.type == MinecraftVersion.Type.Release }
                        }
                        val latestRelease = releases.firstOrNull()
                        val hasOlderReleaseInstalled = releases.any { r ->
                            r !== latestRelease && installedByName.containsKey(r.version.id)
                        }

                        val shown = when (vm.category) {
                            NeonCategory.Recent -> releases.take(RECENT_COUNT)
                            NeonCategory.Old -> releases.drop(RECENT_COUNT)
                            NeonCategory.Beta -> sorted.filter {
                                it.type == MinecraftVersion.Type.OldBeta || it.type == MinecraftVersion.Type.OldAlpha
                            }
                            NeonCategory.Snapshot -> sorted.filter {
                                it.type == MinecraftVersion.Type.Snapshot || it.type == MinecraftVersion.Type.AprilFools
                            }
                            NeonCategory.Cobook -> sorted.filter {
                                installedByName.containsKey(it.version.id) || downloads.containsKey(it.version.id)
                            }
                        }

                        if (shown.isEmpty()) {
                            Box(Modifier.fillMaxSize().padding(24.dp), Alignment.Center) {
                                Text(
                                    text = if (vm.category == NeonCategory.Cobook)
                                        "Seu Cobook está vazio.\nInstale uma versão e ela aparecerá aqui."
                                    else "Nenhuma versão nesta categoria.",
                                    color = NeonDim,
                                    textAlign = TextAlign.Center,
                                    fontSize = 14.sp
                                )
                            }
                        } else {
                            LazyVerticalGrid(
                                columns = GridCells.Adaptive(minSize = 220.dp),
                                modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                items(shown, key = { it.version.id }) { mv ->
                                    val id = mv.version.id
                                    val installed = installedByName[id]
                                    NeonVersionCard(
                                        version = mv,
                                        installed = installed,
                                        download = downloads[id],
                                        updateAvailable = mv === latestRelease && installed == null && hasOlderReleaseInstalled,
                                        artUrl = NeonVersionArt.find(artMap, id),
                                        onInstall = { requestInstall(id) },
                                        onPause = { NeonDownloadManager.pause(id) },
                                        onCancel = { NeonDownloadManager.cancel(id) },
                                        onLaunch = { v ->
                                            eventViewModel.sendEvent(EventViewModel.Event.Launch.Game(v))
                                        },
                                        onReinstall = { v ->
                                            scope.launch {
                                                withContext(Dispatchers.IO) { VersionsManager.deleteVersion(v) }
                                                requestInstall(id)
                                            }
                                        },
                                        onUninstall = { v -> pendingUninstall = v },
                                        onCustomize = { onCustomize(mv) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    pendingMobile?.let { id ->
        SimpleAlertDialog(
            title = "Usando dados móveis",
            text = "Você está sem Wi-Fi. O download de $id pode consumir bastante da sua franquia. Continuar mesmo assim?",
            confirmText = "Baixar mesmo assim",
            dismissText = "Cancelar",
            onConfirm = {
                pendingMobile = null
                NeonDownloadManager.start(context, id)
            },
            onDismiss = { pendingMobile = null }
        )
    }

    pendingUninstall?.let { version ->
        SimpleAlertDialog(
            title = "Desinstalar versão",
            text = "Remover ${version.getVersionName()} do launcher? Mundos e arquivos dessa versão serão apagados.",
            confirmText = "Desinstalar",
            dismissText = "Cancelar",
            onConfirm = {
                pendingUninstall = null
                scope.launch(Dispatchers.IO) { VersionsManager.deleteVersion(version) }
            },
            onDismiss = { pendingUninstall = null }
        )
    }
}

private const val RECENT_COUNT = 15

//region Fundo, cabeçalho e abas
@Composable
private fun Modifier.neonBackground(): Modifier {
    val phase = LocalNeonPhase.current
    return this
        .background(Brush.verticalGradient(listOf(NeonBg2, NeonBg)))
        .drawBehind {
            val t = phase.value * 2f * PI.toFloat()
            val r = size.maxDimension * 0.6f
            drawRect(
                Brush.radialGradient(
                    listOf(NeonPurple.copy(alpha = 0.28f), Color.Transparent),
                    center = Offset(size.width * (0.2f + 0.1f * sin(t)), size.height * 0.15f),
                    radius = r
                )
            )
            drawRect(
                Brush.radialGradient(
                    listOf(NeonPink.copy(alpha = 0.16f), Color.Transparent),
                    center = Offset(size.width * (0.85f - 0.1f * sin(t)), size.height * 0.9f),
                    radius = r
                )
            )
        }
}

@Composable
private fun NeonHeader(
    category: NeonCategory,
    onSelect: (NeonCategory) -> Unit,
    onRefresh: () -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Selecionar Versões",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            NeonRoundButton(glyph = "↻", onClick = onRefresh)
        }
        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            NeonCategory.entries.forEach { c ->
                NeonTab(c, selected = c == category, onClick = { onSelect(c) })
            }
        }
    }
}

@Composable
private fun NeonTab(category: NeonCategory, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.94f else 1f, spring(), label = "tabScale")
    val bg by animateColorAsState(if (selected) Color(0xFF2B1457) else Color(0xFF140B28), tween(250), label = "tabBg")
    val fg by animateColorAsState(if (selected) Color.White else NeonDim, tween(250), label = "tabFg")
    val glow by animateFloatAsState(if (selected) 1f else 0f, tween(300), label = "tabGlow")

    Row(
        modifier = Modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(
                elevation = (14f * glow).dp,
                shape = shape,
                ambientColor = NeonPurple,
                spotColor = NeonPurple
            )
            .clip(shape)
            .background(bg)
            .border(
                BorderStroke(
                    1.5.dp,
                    if (selected) Brush.linearGradient(listOf(NeonViolet, NeonPurple, NeonPink))
                    else Brush.linearGradient(listOf(Color(0xFF3A2468), Color(0xFF2A1A4D)))
                ),
                shape
            )
            .clickable(interaction, indication = null, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(category.glyph, color = if (selected) NeonViolet else fg, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text(category.label, color = fg, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun NeonRoundButton(glyph: String, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.88f else 1f, spring(), label = "roundScale")
    Box(
        modifier = Modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .size(38.dp)
            .shadow(8.dp, CircleShape, ambientColor = NeonPurple, spotColor = NeonPurple)
            .clip(CircleShape)
            .background(Color(0xFF2B1457))
            .border(1.5.dp, NeonPurple, CircleShape)
            .clickable(interaction, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(glyph, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun NeonSpinner() {
    val phase = LocalNeonPhase.current
    Canvas(Modifier.size(56.dp)) {
        val stroke = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
        drawArc(
            color = NeonPurple.copy(alpha = 0.25f),
            startAngle = 0f, sweepAngle = 360f, useCenter = false, style = stroke
        )
        drawArc(
            brush = Brush.sweepGradient(listOf(NeonPink, NeonPurple, NeonViolet)),
            startAngle = phase.value * 720f % 360f, sweepAngle = 100f, useCenter = false, style = stroke
        )
    }
}
//endregion

//region Cartão da versão
@Composable
private fun NeonVersionCard(
    version: MinecraftVersion,
    installed: Version?,
    download: NeonDownloadManager.Item?,
    updateAvailable: Boolean,
    artUrl: String?,
    onInstall: () -> Unit,
    onPause: () -> Unit,
    onCancel: () -> Unit,
    onLaunch: (Version) -> Unit,
    onReinstall: (Version) -> Unit,
    onUninstall: (Version) -> Unit,
    onCustomize: () -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    val text = remember(version) { neonVersionText(version) }
    val phase = LocalNeonPhase.current

    //entrada animada própria
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, tween(380)) }

    val accent = when {
        installed != null -> NeonGreen
        download != null -> NeonPink
        else -> NeonPurple
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                val s = 0.92f + 0.08f * appear.value
                scaleX = s; scaleY = s; alpha = appear.value
            }
            .shadow(14.dp, shape, ambientColor = accent, spotColor = accent)
            .clip(shape)
            .background(NeonCard)
            .drawBehind {
                //luz neon que percorre a borda do cartão
                val x = size.width * (phase.value * 2f - 0.5f)
                drawRect(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, accent.copy(alpha = 0.10f), Color.Transparent),
                        startX = x, endX = x + size.width * 0.6f
                    ),
                    size = Size(size.width, size.height)
                )
            }
            .border(1.5.dp, Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.25f), NeonViolet)), shape)
    ) {
        //Arte oficial da versão
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
            if (artUrl == null) {
                NeonArtFallback(version.type)
            } else {
                SubcomposeAsyncImage(
                    model = artUrl,
                    contentDescription = version.version.id,
                    modifier = Modifier.matchParentSize(),
                    contentScale = ContentScale.Crop,
                    loading = { NeonArtFallback(version.type) },
                    error = { NeonArtFallback(version.type) }
                )
            }
            Box(
                Modifier.matchParentSize().background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Transparent, NeonCard.copy(alpha = 0.95f))
                    )
                )
            )
            Row(
                Modifier.align(Alignment.TopEnd).padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (updateAvailable) NeonBadge("ATUALIZAÇÃO", NeonPink)
                if (installed != null) NeonBadge("✔ INSTALADA", NeonGreen)
            }
        }

        Column(
            Modifier.padding(start = 12.dp, end = 12.dp, bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = version.version.id,
                    color = Color.White,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                NeonBadge(text.typeLabel, NeonViolet)
            }
            Text(
                text = text.title,
                color = NeonViolet,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = text.description,
                color = NeonDim,
                fontSize = 11.sp,
                lineHeight = 15.sp,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.heightIn(min = 45.dp)
            )
            Text(
                text = "⚡ ${text.compat}",
                color = NeonGreen,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(2.dp))

            when {
                download != null -> NeonDownloadPanel(download, onInstall, onPause, onCancel)
                installed != null -> NeonInstalledRow(
                    installed = installed,
                    onLaunch = { onLaunch(installed) },
                    onReinstall = { onReinstall(installed) },
                    onUninstall = { onUninstall(installed) }
                )
                else -> Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NeonButton(
                        text = if (updateAvailable) "Atualizar" else "Instalar",
                        iconRes = R.drawable.ic_download,
                        onClick = onInstall,
                        modifier = Modifier.weight(1f)
                    )
                    NeonRoundButton(glyph = "⚙", onClick = onCustomize)
                }
            }
        }
    }
}

@Composable
private fun NeonArtFallback(type: MinecraftVersion.Type) {
    val res = when (type) {
        MinecraftVersion.Type.Release -> R.drawable.img_minecraft
        MinecraftVersion.Type.Snapshot -> R.drawable.img_command_block
        MinecraftVersion.Type.AprilFools -> R.drawable.img_diamond_block
        MinecraftVersion.Type.OldBeta -> R.drawable.img_old_cobblestone
        MinecraftVersion.Type.OldAlpha -> R.drawable.img_old_grass_block
        else -> R.drawable.img_minecraft
    }
    Box(
        Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Color(0xFF3B1B7A), Color(0xFF12082A), Color(0xFF5B1D8F)))
        ),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(res),
            contentDescription = null,
            modifier = Modifier.size(64.dp).alpha(0.9f)
        )
    }
}

@Composable
private fun NeonBadge(text: String, color: Color) {
    Text(
        text = text,
        color = color,
        fontSize = 9.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xCC0B0618))
            .border(1.dp, color, RoundedCornerShape(8.dp))
            .padding(horizontal = 7.dp, vertical = 3.dp)
    )
}
//endregion

//region Download / instalado
@Composable
private fun NeonDownloadPanel(
    item: NeonDownloadManager.Item,
    onResume: () -> Unit,
    onPause: () -> Unit,
    onCancel: () -> Unit
) {
    val status = item.status
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        when (status) {
            NeonDownloadManager.Status.Error -> {
                Text(
                    text = item.error ?: "Falha no download",
                    color = NeonRed,
                    fontSize = 11.sp,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
            NeonDownloadManager.Status.Queued -> {
                NeonProgressBar(progress = -1f, active = true)
                Text("Na fila de download…", color = NeonDim, fontSize = 11.sp)
            }
            else -> {
                val active = status == NeonDownloadManager.Status.Downloading
                NeonProgressBar(progress = item.progress, active = active)

                val percent = if (item.progress >= 0f) "${(item.progress * 100).toInt()}%" else "—"
                val phaseLabel = when {
                    !active -> "Pausado"
                    item.phase == NeonDownloadManager.Phase.Preparing -> "Preparando"
                    item.phase == NeonDownloadManager.Phase.Installing -> "Instalando"
                    else -> "Baixando"
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("$phaseLabel · $percent", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    if (active && item.speedBytes > 0) {
                        Text("${formatFileSize(item.speedBytes)}/s", color = NeonViolet, fontSize = 11.sp)
                    }
                }
                if (item.downloadedBytes > 0) {
                    val total = if (item.totalBytesEstimate > 0) " de ~${formatFileSize(item.totalBytesEstimate)}" else ""
                    Text("Baixado: ${formatFileSize(item.downloadedBytes)}$total", color = NeonDim, fontSize = 10.sp)
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            when (status) {
                NeonDownloadManager.Status.Downloading, NeonDownloadManager.Status.Queued -> NeonButton(
                    text = "Pausar", glyph = "❚❚", brush = GhostBrush, onClick = onPause,
                    modifier = Modifier.weight(1f)
                )
                NeonDownloadManager.Status.Paused -> NeonButton(
                    text = "Continuar", glyph = "▶", onClick = onResume, modifier = Modifier.weight(1f)
                )
                NeonDownloadManager.Status.Error -> NeonButton(
                    text = "Tentar de novo", glyph = "↻", onClick = onResume, modifier = Modifier.weight(1f)
                )
            }
            NeonButton(text = "Cancelar", glyph = "✕", brush = RedBrush, onClick = onCancel, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun NeonProgressBar(progress: Float, active: Boolean) {
    val phase = LocalNeonPhase.current
    val animated by animateFloatAsState(progress.coerceAtLeast(0f), tween(400), label = "progress")
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .fillMaxWidth()
            .height(9.dp)
            .clip(shape)
            .background(Color(0xFF2A1A4D))
            .drawBehind {
                if (progress < 0f) {
                    //indeterminado: trecho brilhante deslizando
                    val w = size.width * 0.35f
                    val x = (size.width + w) * phase.value - w
                    drawRoundRect(
                        PurpleBrush,
                        topLeft = Offset(x, 0f),
                        size = Size(w, size.height),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.height / 2)
                    )
                } else {
                    val w = size.width * animated
                    drawRoundRect(
                        Brush.horizontalGradient(listOf(NeonPurple, NeonPink), endX = size.width),
                        size = Size(w, size.height),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.height / 2)
                    )
                    if (active && w > 0f) {
                        val sx = w * (phase.value * 2f - 0.5f)
                        drawRect(
                            Brush.horizontalGradient(
                                listOf(Color.Transparent, Color.White.copy(alpha = 0.45f), Color.Transparent),
                                startX = sx, endX = sx + w * 0.4f
                            ),
                            size = Size(w, size.height)
                        )
                    }
                }
            }
    )
}

@Composable
private fun NeonInstalledRow(
    installed: Version,
    onLaunch: () -> Unit,
    onReinstall: () -> Unit,
    onUninstall: () -> Unit
) {
    val valid = remember(installed) { installed.isValid() }
    var menu by remember { mutableStateOf(false) }

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (valid) {
            NeonButton(
                text = "Iniciar", glyph = "▶", brush = GreenBrush,
                onClick = onLaunch, modifier = Modifier.weight(1f)
            )
        } else {
            NeonButton(
                text = "Reparar", glyph = "↻", onClick = onReinstall, modifier = Modifier.weight(1f)
            )
        }
        Box {
            NeonRoundButton(glyph = "⋮", onClick = { menu = true })
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Atualizar / reinstalar") },
                    onClick = { menu = false; onReinstall() }
                )
                DropdownMenuItem(
                    text = { Text("Desinstalar", color = NeonRed) },
                    onClick = { menu = false; onUninstall() }
                )
            }
        }
    }
}
//endregion

//region Botão neon animado
@Composable
private fun NeonButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    brush: Brush = PurpleBrush,
    iconRes: Int? = null,
    glyph: String? = null
) {
    val shape = RoundedCornerShape(14.dp)
    val phase = LocalNeonPhase.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.92f else 1f, spring(dampingRatio = 0.5f), label = "btnScale")

    Row(
        modifier = modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .heightIn(min = 40.dp)
            .shadow(10.dp, shape, ambientColor = NeonPurple, spotColor = NeonPurple)
            .clip(shape)
            .background(brush)
            .drawBehind {
                //brilho que varre o botão
                val x = size.width * (phase.value * 2f - 0.5f)
                drawRect(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.28f), Color.Transparent),
                        startX = x, endX = x + size.width * 0.4f
                    )
                )
            }
            .clickable(interaction, indication = null, onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (iconRes != null) {
            Icon(
                painter = painterResource(iconRes),
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(6.dp))
        } else if (glyph != null) {
            Text(glyph, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(6.dp))
        }
        Text(
            text = text,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
//endregion
