/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.ui.screens.content.elements

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.movtery.petlib.PetAnimation
import com.movtery.zalithlauncher.R
import com.movtery.zalithlauncher.game.account.Account
import com.movtery.zalithlauncher.game.account.isLocalAccount
import com.movtery.zalithlauncher.game.account.isMicrosoftAccount
import com.movtery.zalithlauncher.game.account.wardrobe.CosmeticCatalog
import com.movtery.zalithlauncher.game.account.wardrobe.CosmeticCategory
import com.movtery.zalithlauncher.game.account.wardrobe.CosmeticItem
import com.movtery.zalithlauncher.game.account.wardrobe.CosmeticSelection
import com.movtery.zalithlauncher.game.account.wardrobe.CosmeticStore
import com.movtery.zalithlauncher.game.account.wardrobe.EmptyCape
import com.movtery.zalithlauncher.game.account.wardrobe.SkinModelType
import com.movtery.zalithlauncher.game.account.wardrobe.isSlimModel
import com.movtery.zalithlauncher.game.account.wardrobe.toArmModel
import com.movtery.zalithlauncher.game.account.yggdrasil.PlayerProfile
import com.movtery.zalithlauncher.game.account.yggdrasil.findUsing
import com.movtery.zalithlauncher.game.account.yggdrasil.getFile
import com.movtery.zalithlauncher.path.PathManager
import com.movtery.zalithlauncher.ui.components.PetModelView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// ------------------------------------------------------------------ paleta neon

private val NeonViolet = Color(0xFFB57BFF)
private val NeonPurple = Color(0xFF7B2FFF)
private val NeonMagenta = Color(0xFFE879F9)
private val PanelDark = Color(0xFF07040F)
private val PanelMid = Color(0xFF160B2B)
private val CellDark = Color(0xFF1B1033)
private val TextSoft = Color(0xFFD9CCFF)

private val NeonBrush = Brush.linearGradient(listOf(NeonMagenta, NeonPurple, NeonViolet))

// ------------------------------------------------------------- componentes base

@Composable
private fun NeonButton(
    text: String,
    modifier: Modifier = Modifier,
    iconRes: Int? = null,
    filled: Boolean = false,
    enabled: Boolean = true,
    loading: Boolean = false,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    val background = if (filled) {
        Brush.horizontalGradient(listOf(NeonPurple, NeonMagenta))
    } else {
        Brush.verticalGradient(listOf(Color(0xFF241446), PanelMid))
    }
    Row(
        modifier = modifier
            .alpha(if (enabled) 1f else 0.45f)
            .shadow(
                elevation = if (filled && enabled) 10.dp else 0.dp,
                shape = shape,
                ambientColor = NeonPurple,
                spotColor = NeonPurple
            )
            .clip(shape)
            .background(background)
            .border(1.5.dp, NeonBrush, shape)
            .clickable(enabled = enabled && !loading, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 11.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                strokeWidth = 2.dp,
                color = Color.White
            )
            Spacer(Modifier.width(8.dp))
        } else if (iconRes != null) {
            Icon(
                modifier = Modifier.size(18.dp),
                painter = painterResource(iconRes),
                contentDescription = null,
                tint = Color.White
            )
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text = text,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun NeonChip(
    text: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                if (selected) Brush.horizontalGradient(listOf(NeonPurple, NeonMagenta))
                else Brush.verticalGradient(listOf(Color(0xFF241446), PanelMid))
            )
            .border(1.dp, if (selected) NeonViolet else NeonPurple.copy(alpha = 0.5f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1
        )
    }
}

@Composable
private fun CircleArrow(iconRes: Int, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(40.dp)
            .shadow(8.dp, CircleShape, ambientColor = NeonPurple, spotColor = NeonPurple)
            .clip(CircleShape)
            .background(Color(0xCC1B1033))
            .border(1.5.dp, NeonBrush, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            modifier = Modifier.size(24.dp),
            painter = painterResource(iconRes),
            contentDescription = null,
            tint = Color.White
        )
    }
}

@Composable
private fun CategoryTab(
    text: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                if (selected) Brush.horizontalGradient(listOf(NeonPurple, Color(0xFF9B4DFF)))
                else Brush.verticalGradient(listOf(Color(0xFF1E1238), PanelMid))
            )
            .border(
                width = if (selected) 1.5.dp else 1.dp,
                brush = if (selected) NeonBrush else Brush.linearGradient(listOf(NeonPurple.copy(0.4f), NeonPurple.copy(0.4f))),
                shape = shape
            )
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (selected) Color.White else TextSoft,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

/** Miniatura do item, desenhada sobre a skin real do jogador */
@Composable
private fun ItemThumb(item: CosmeticItem, baseBytes: ByteArray?, modifier: Modifier = Modifier) {
    val thumb by produceState<ImageBitmap?>(null, item.id, baseBytes) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val bmp: Bitmap? = if (item.category == CosmeticCategory.CAPE) {
                    CosmeticCatalog.capeThumbnail(item.id)
                } else {
                    val bytes = baseBytes ?: return@runCatching null
                    val base = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return@runCatching null
                    if (item.category == CosmeticCategory.CLOTHES) {
                        CosmeticCatalog.clothesThumbnail(base, item)
                    } else {
                        CosmeticCatalog.headThumbnail(base, item)
                    }
                }
                bmp?.asImageBitmap()
            }.getOrNull()
        }
    }
    val image = thumb
    if (image != null) {
        Image(
            modifier = modifier,
            bitmap = image,
            contentDescription = null,
            filterQuality = FilterQuality.None
        )
    }
}

@Composable
private fun ItemCell(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .shadow(
                    elevation = if (selected) 12.dp else 0.dp,
                    shape = shape,
                    ambientColor = NeonViolet,
                    spotColor = NeonViolet
                )
                .clip(shape)
                .background(
                    Brush.verticalGradient(
                        if (selected) listOf(Color(0xFF3A1D78), Color(0xFF241446))
                        else listOf(CellDark, Color(0xFF110A22))
                    )
                )
                .border(
                    width = if (selected) 2.dp else 1.dp,
                    brush = if (selected) NeonBrush else Brush.linearGradient(listOf(NeonPurple.copy(0.35f), NeonPurple.copy(0.35f))),
                    shape = shape
                )
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            content()
        }
        Text(
            text = label,
            color = if (selected) Color.White else TextSoft,
            fontSize = 10.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

// ----------------------------------------------------------------- tela principal

private data class ApplyPlan(
    val skinFile: File?,
    val model: SkinModelType,
    val reset: Boolean
)

/**
 * Tela "Personalizar Personagem".
 *
 * Substitui o diálogo antigo de troca de skin mantendo todas as funções dele:
 * importar skin, estilo de braço, capas da conta Microsoft, redefinir skin,
 * e acrescenta chapéus, roupas, acessórios e capas locais (contas offline),
 * com pré-visualização 3D, rotação e animações.
 */
@Composable
fun CharacterCustomizerDialog(
    account: Account,
    availableCapes: List<PlayerProfile.Cape>? = null,
    skinState: ChangeSkin,
    onSkinStateChange: (ChangeSkin) -> Unit,
    capeState: ChangeCape,
    onCapeStateChange: (ChangeCape) -> Unit,
    isImportingSkin: Boolean,
    onSkinPicked: (Uri) -> Unit,
    onDismissRequest: () -> Unit,
    onResetSkin: () -> Unit,
    onApplySkin: (File, SkinModelType) -> Unit,
    onApplyCape: (PlayerProfile.Cape) -> Unit,
    onApplyLocalCape: (ByteArray?) -> Unit,
    onFetchCapes: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val uuid = account.uniqueUUID
    val isMicrosoft = account.isMicrosoftAccount()
    val isLocal = account.isLocalAccount()

    // ---- seleção de itens
    val initialSelection = remember(uuid) { CosmeticStore.load(uuid) }
    var selection by remember(uuid) { mutableStateOf(initialSelection) }
    var tab by remember { mutableStateOf(CosmeticCategory.HAT) }

    // ---- capas da conta Microsoft (mesma lógica do diálogo antigo)
    var showCapeSelector by remember { mutableStateOf(false) }
    var isFetchingCapes by remember { mutableStateOf(false) }
    var currentCapeToLoad by remember { mutableStateOf(EmptyCape) }
    var currentUsingCape by remember { mutableStateOf(EmptyCape) }

    LaunchedEffect(availableCapes) {
        if (isMicrosoft) {
            if (availableCapes != null) {
                isFetchingCapes = false
                val using = availableCapes.findUsing() ?: EmptyCape
                currentUsingCape = using
                currentCapeToLoad = using
            } else {
                isFetchingCapes = true
                onFetchCapes()
            }
        }
    }

    val microsoftCape by produceState<ByteArray?>(null, currentCapeToLoad, availableCapes) {
        if (!isMicrosoft) return@produceState
        value = withContext(Dispatchers.IO) {
            if (currentCapeToLoad != EmptyCape) {
                runCatching {
                    currentCapeToLoad.getFile(PathManager.DIR_ACCOUNT_CAPE).inputStream().use { it.readBytes() }
                }.getOrNull()
            } else if (availableCapes == null && account.getCapeFile().exists()) {
                runCatching { account.getCapeFile().inputStream().use { it.readBytes() } }.getOrNull()
            } else null
        }
    }

    val localCape: ByteArray? = remember(selection.cape) {
        selection.cape?.let { CosmeticCatalog.capePng(it) }
    }
    val previewCape: ByteArray? = if (isLocal) localCape else microsoftCape

    // ---- skin base (sem itens)
    val modelType = when (skinState) {
        ChangeSkin.None -> account.skinModelType
        is ChangeSkin.ChangeSkinData -> skinState.data.getModelType()
        ChangeSkin.ResetSkin -> SkinModelType.STEVE
    }
    val previewArm = when (skinState) {
        ChangeSkin.None -> account.skinModelType.toArmModel()
        is ChangeSkin.ChangeSkinData -> skinState.data.getModelType().toArmModel()
        ChangeSkin.ResetSkin -> com.movtery.petlib.ArmModel.Classic
    }

    // Retorna a skin base e se ela é a skin padrão (nenhuma skin própria)
    val baseInfo by produceState<Pair<ByteArray, Boolean>?>(null, skinState) {
        value = withContext(Dispatchers.IO) {
            fun default(): Pair<ByteArray, Boolean> {
                val name = if (modelType == SkinModelType.ALEX) "skin/alex.png" else "skin/steve.png"
                return context.assets.open(name).use { it.readBytes() } to true
            }
            runCatching {
                when (skinState) {
                    is ChangeSkin.ChangeSkinData -> skinState.cacheFile.readBytes() to false
                    ChangeSkin.ResetSkin -> default()
                    ChangeSkin.None -> {
                        val baseFile = CosmeticStore.baseFile(uuid)
                        when {
                            baseFile.exists() -> baseFile.readBytes() to false
                            account.getSkinFile().exists() -> account.getSkinFile().readBytes() to false
                            else -> default()
                        }
                    }
                }
            }.getOrElse { default() }
        }
    }
    val baseBytes: ByteArray? = baseInfo?.first

    // ---- skin com os itens aplicados (pré-visualização ao vivo)
    val skinSelection = selection.skinPart()
    val previewSkin by produceState<ByteArray?>(null, baseBytes, skinSelection) {
        val bytes = baseBytes ?: return@produceState
        value = withContext(Dispatchers.IO) {
            if (!skinSelection.hasSkinItems) {
                bytes
            } else {
                runCatching {
                    val base = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    CosmeticCatalog.toPng(CosmeticCatalog.composeSkin(base, skinSelection))
                }.getOrDefault(bytes)
            }
        }
    }

    // ---- controles do modelo 3D
    val yaw = remember { Animatable(0f) }
    var animation by remember { mutableStateOf(PetAnimation.Idle) }
    var autoSpin by remember { mutableStateOf(false) }
    LaunchedEffect(autoSpin) {
        while (autoSpin) {
            yaw.snapTo(yaw.value + 0.03f)
            delay(16)
        }
    }

    val skinPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let(onSkinPicked)
    }

    val hasChanges = skinState != ChangeSkin.None ||
            capeState != ChangeCape.None ||
            selection != initialSelection

    // ---- aplicar tudo
    fun applyAll() {
        scope.launch {
            val plan = withContext(Dispatchers.IO) {
                val imported = skinState is ChangeSkin.ChangeSkinData
                val reset = skinState is ChangeSkin.ResetSkin
                val itemsChanged = selection.skinPart() != initialSelection.skinPart()

                var file: File? = null
                var model = modelType

                if (reset) {
                    // Redefinir remove a skin e todos os itens de roupa/chapéu/acessório
                    CosmeticStore.clear(uuid)
                } else if (imported || itemsChanged) {
                    val (bytes, isDefault) = baseInfo ?: return@withContext ApplyPlan(null, model, false)

                    if (model == SkinModelType.NONE) {
                        val probe = File(PathManager.DIR_CACHE, "cosmetic_probe_$uuid.png")
                        probe.writeBytes(bytes)
                        model = if (probe.isSlimModel()) SkinModelType.ALEX else SkinModelType.STEVE
                        probe.delete()
                    }

                    when {
                        // Skin importada sem itens: usa o arquivo original sem reprocessar
                        imported && !selection.hasSkinItems -> {
                            file = (skinState as ChangeSkin.ChangeSkinData).cacheFile
                        }
                        // Sem itens e sem skin própria: não há nada para enviar
                        !selection.hasSkinItems && isDefault && !imported -> {}
                        else -> {
                            val out = File(PathManager.DIR_CACHE, "cosmetic_skin_${uuid}_${System.currentTimeMillis()}.png")
                            if (selection.hasSkinItems) {
                                val base = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                out.writeBytes(CosmeticCatalog.toPng(CosmeticCatalog.composeSkin(base, selection)))
                            } else {
                                // Todos os itens removidos: volta para a skin original
                                out.writeBytes(bytes)
                            }
                            file = out
                        }
                    }
                    if (!isDefault || imported) CosmeticStore.saveBase(uuid, bytes)
                }
                if (!reset) CosmeticStore.save(uuid, selection) else CosmeticStore.save(uuid, CosmeticSelection(cape = selection.cape))
                ApplyPlan(file, model, reset)
            }

            if (plan.reset) onResetSkin()
            plan.skinFile?.let { onApplySkin(it, plan.model) }
            if (isLocal && selection.cape != initialSelection.cape) {
                onApplyLocalCape(selection.cape?.let { CosmeticCatalog.capePng(it) })
            }
            if (capeState is ChangeCape.ChangeCapeData) onApplyCape(capeState.cape)
            onDismissRequest()
        }
    }

    fun removeAll() {
        selection = CosmeticSelection()
        if (isMicrosoft && currentUsingCape != EmptyCape) {
            onCapeStateChange(ChangeCape.ChangeCapeData(EmptyCape))
            currentCapeToLoad = EmptyCape
        }
    }

    val pulse by rememberInfiniteTransition(label = "neon").animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Reverse),
        label = "neonPulse"
    )
    val frameBrush = Brush.linearGradient(
        listOf(NeonMagenta.copy(alpha = pulse), NeonPurple.copy(alpha = pulse), NeonViolet.copy(alpha = pulse))
    )
    val frameShape = RoundedCornerShape(26.dp)

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize().padding(10.dp)) {
            val wide = maxWidth > maxHeight

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .shadow(18.dp, frameShape, ambientColor = NeonPurple, spotColor = NeonPurple)
                    .clip(frameShape)
                    .background(Brush.verticalGradient(listOf(PanelMid, PanelDark)))
                    .border(2.dp, frameBrush, frameShape)
                    .padding(14.dp)
            ) {
                // ---- cabeçalho
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, NeonBrush, CircleShape)
                            .clickable(onClick = onDismissRequest),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            modifier = Modifier.size(22.dp),
                            painter = painterResource(R.drawable.ic_arrow_back),
                            contentDescription = stringResource(R.string.generic_cancel),
                            tint = Color.White
                        )
                    }
                    Text(
                        text = stringResource(R.string.cosmetic_title),
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(Modifier.height(10.dp))

                val previewPanel: @Composable (Modifier) -> Unit = { modifier ->
                    PreviewPanel(
                        modifier = modifier,
                        skin = previewSkin,
                        cape = previewCape,
                        arm = previewArm,
                        yaw = yaw.value,
                        animation = animation,
                        autoSpin = autoSpin,
                        skinState = skinState,
                        onSkinStateChange = onSkinStateChange,
                        onRotate = { delta ->
                            scope.launch { yaw.animateTo(yaw.targetValue + delta, tween(320)) }
                        },
                        onAnimation = { animation = it },
                        onAutoSpin = { autoSpin = !autoSpin }
                    )
                }

                val controlsPanel: @Composable (Modifier) -> Unit = { modifier ->
                    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        // abas
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            CategoryTab(stringResource(R.string.cosmetic_tab_hats), tab == CosmeticCategory.HAT, Modifier.weight(1f)) { tab = CosmeticCategory.HAT }
                            CategoryTab(stringResource(R.string.cosmetic_tab_clothes), tab == CosmeticCategory.CLOTHES, Modifier.weight(1f)) { tab = CosmeticCategory.CLOTHES }
                            CategoryTab(stringResource(R.string.cosmetic_tab_capes), tab == CosmeticCategory.CAPE, Modifier.weight(1f)) { tab = CosmeticCategory.CAPE }
                            CategoryTab(stringResource(R.string.cosmetic_tab_accessories), tab == CosmeticCategory.ACCESSORY, Modifier.weight(1f)) { tab = CosmeticCategory.ACCESSORY }
                        }

                        // conteúdo da aba
                        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                            if (tab == CosmeticCategory.CAPE && !isLocal) {
                                MicrosoftCapeInfo(
                                    supported = isMicrosoft,
                                    loading = isFetchingCapes,
                                    onOpen = { showCapeSelector = true }
                                )
                            } else {
                                val catalog = CosmeticCatalog.items(tab)
                                val current = selection.get(tab)
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    if (tab == CosmeticCategory.CAPE) {
                                        Text(
                                            text = stringResource(R.string.cosmetic_minecraft_capes),
                                            color = TextSoft,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                    LazyVerticalGrid(
                                        modifier = Modifier.fillMaxSize(),
                                        columns = GridCells.Adaptive(72.dp),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        item(key = "none_${tab.name}") {
                                            ItemCell(
                                                label = stringResource(R.string.cosmetic_none),
                                                selected = current == null,
                                                onClick = { selection = selection.with(tab, null) }
                                            ) {
                                                Icon(
                                                    modifier = Modifier.size(28.dp),
                                                    painter = painterResource(R.drawable.ic_close),
                                                    contentDescription = null,
                                                    tint = TextSoft
                                                )
                                            }
                                        }
                                        items(catalog, key = { it.id }) { item ->
                                            ItemCell(
                                                label = stringResource(item.nameRes),
                                                selected = current == item.id,
                                                onClick = {
                                                    // tocar de novo no item equipado remove o item
                                                    selection = selection.with(tab, if (current == item.id) null else item.id)
                                                }
                                            ) {
                                                ItemThumb(
                                                    item = item,
                                                    baseBytes = baseBytes,
                                                    modifier = Modifier.fillMaxSize().padding(10.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // botões de ação
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NeonButton(
                                text = stringResource(R.string.cosmetic_import_skin),
                                modifier = Modifier.weight(1f),
                                iconRes = R.drawable.ic_upload,
                                loading = isImportingSkin,
                                onClick = { skinPicker.launch(arrayOf("image/png")) }
                            )
                            NeonButton(
                                text = stringResource(R.string.cosmetic_select_cape),
                                modifier = Modifier.weight(1f),
                                iconRes = R.drawable.ic_styler,
                                enabled = isLocal || (isMicrosoft && !isFetchingCapes),
                                onClick = {
                                    if (isMicrosoft) showCapeSelector = true else tab = CosmeticCategory.CAPE
                                }
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NeonButton(
                                text = stringResource(R.string.cosmetic_remove_all),
                                modifier = Modifier.weight(1f),
                                iconRes = R.drawable.ic_delete_outlined,
                                enabled = !selection.isEmpty || (isMicrosoft && currentUsingCape != EmptyCape),
                                onClick = { removeAll() }
                            )
                            if (isLocal && account.hasSkinFile && skinState != ChangeSkin.ResetSkin) {
                                NeonButton(
                                    text = stringResource(R.string.generic_reset),
                                    modifier = Modifier.weight(1f),
                                    iconRes = R.drawable.ic_restart_alt,
                                    onClick = {
                                        selection = selection.copy(hat = null, clothes = null, accessory = null)
                                        onSkinStateChange(ChangeSkin.ResetSkin)
                                    }
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NeonButton(
                                text = stringResource(R.string.generic_cancel),
                                modifier = Modifier.weight(1f),
                                onClick = onDismissRequest
                            )
                            NeonButton(
                                text = stringResource(R.string.cosmetic_apply),
                                modifier = Modifier.weight(1f),
                                filled = true,
                                enabled = hasChanges && !isImportingSkin,
                                onClick = { applyAll() }
                            )
                        }
                    }
                }

                if (wide) {
                    Row(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        previewPanel(Modifier.weight(0.42f).fillMaxHeight())
                        controlsPanel(Modifier.weight(0.58f).fillMaxHeight())
                    }
                } else {
                    Column(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        previewPanel(Modifier.weight(0.42f).fillMaxWidth())
                        controlsPanel(Modifier.weight(0.58f).fillMaxWidth())
                    }
                }
            }
        }
    }

    if (showCapeSelector) {
        val cape = if (capeState is ChangeCape.ChangeCapeData) capeState.cape else currentUsingCape
        SelectCapeDialog(
            capes = buildList {
                add(EmptyCape)
                addAll(availableCapes ?: emptyList())
            },
            selectedCape = cape,
            onSelected = { selected ->
                val state = if (selected != currentUsingCape) {
                    ChangeCape.ChangeCapeData(selected)
                } else {
                    ChangeCape.None
                }
                onCapeStateChange(state)
                currentCapeToLoad = selected
                showCapeSelector = false
            },
            onDismiss = { showCapeSelector = false }
        )
    }
}

@Composable
private fun PreviewPanel(
    modifier: Modifier,
    skin: ByteArray?,
    cape: ByteArray?,
    arm: com.movtery.petlib.ArmModel?,
    yaw: Float,
    animation: PetAnimation,
    autoSpin: Boolean,
    skinState: ChangeSkin,
    onSkinStateChange: (ChangeSkin) -> Unit,
    onRotate: (Float) -> Unit,
    onAnimation: (PetAnimation) -> Unit,
    onAutoSpin: () -> Unit
) {
    val shape = RoundedCornerShape(22.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(Brush.radialGradient(listOf(Color(0xFF34186B), Color(0xFF0E0820))))
            .border(1.dp, NeonPurple.copy(alpha = 0.6f), shape)
    ) {
        // pedestal neon
        Canvas(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(0.7f)
                .height(48.dp)
                .padding(bottom = 30.dp)
        ) {
            drawOval(
                brush = Brush.radialGradient(
                    colors = listOf(NeonViolet, NeonPurple.copy(alpha = 0.35f), Color.Transparent),
                    center = center,
                    radius = size.width / 2f
                ),
                size = size
            )
        }

        PetModelView(
            modifier = Modifier.fillMaxSize().padding(bottom = 36.dp),
            skin = skin,
            cape = cape,
            arm = arm,
            yaw = yaw,
            animation = animation,
            animationSpeed = 0.8f,
            gazeEnabled = false
        )

        CircleArrow(
            iconRes = R.drawable.ic_arrow_left_rounded,
            onClick = { onRotate(-0.785f) },
            modifier = Modifier.align(Alignment.CenterStart).padding(start = 8.dp)
        )
        CircleArrow(
            iconRes = R.drawable.ic_arrow_right_rounded,
            onClick = { onRotate(0.785f) },
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 8.dp)
        )

        Column(
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (skinState is ChangeSkin.ChangeSkinData) {
                val model = skinState.data.getModelTypeNullable()
                val rejected = skinState.data is ChangeSkin.SkinModel.Rejected
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    NeonChip(
                        text = stringResource(R.string.account_change_skin_arm_wide),
                        selected = model == SkinModelType.STEVE
                    ) {
                        if (!rejected) onSkinStateChange(
                            skinState.copy(data = ChangeSkin.SkinModel.Model(SkinModelType.STEVE))
                        )
                    }
                    NeonChip(
                        text = stringResource(R.string.account_change_skin_arm_slim),
                        selected = model == SkinModelType.ALEX
                    ) {
                        if (!rejected) onSkinStateChange(
                            skinState.copy(data = ChangeSkin.SkinModel.Model(SkinModelType.ALEX))
                        )
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                NeonChip(stringResource(R.string.cosmetic_anim_idle), animation == PetAnimation.Idle) {
                    onAnimation(PetAnimation.Idle)
                }
                NeonChip(stringResource(R.string.cosmetic_anim_walk), animation == PetAnimation.Walking) {
                    onAnimation(PetAnimation.Walking)
                }
                NeonChip(stringResource(R.string.cosmetic_anim_spin), autoSpin) {
                    onAutoSpin()
                }
            }
        }
    }
}

@Composable
private fun MicrosoftCapeInfo(
    supported: Boolean,
    loading: Boolean,
    onOpen: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = stringResource(
                if (supported) R.string.cosmetic_cape_microsoft_hint else R.string.cosmetic_cape_unsupported
            ),
            color = TextSoft,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium
        )
        if (supported) {
            Spacer(Modifier.height(12.dp))
            NeonButton(
                text = stringResource(R.string.cosmetic_select_cape),
                iconRes = R.drawable.ic_styler,
                loading = loading,
                onClick = onOpen
            )
        }
    }
}
