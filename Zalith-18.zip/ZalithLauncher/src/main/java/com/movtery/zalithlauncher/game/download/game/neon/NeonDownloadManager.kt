/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.game.download.game.neon

import android.content.Context
import com.movtery.zalithlauncher.coroutine.TaskStage
import com.movtery.zalithlauncher.game.download.game.GameDownloadInfo
import com.movtery.zalithlauncher.game.download.game.GameInstaller
import com.movtery.zalithlauncher.game.version.installed.VersionsManager
import com.movtery.zalithlauncher.utils.logging.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

private const val TAG = "NeonDownloadManager"

/**
 * Gerenciador de downloads da tela de versões.
 *
 * Usa o [GameInstaller] original do launcher (nenhum mecanismo de download/execução foi trocado).
 * Como o instalador trabalha com uma única pasta temporária, os downloads rodam um por vez e os
 * demais ficam na fila.
 *
 * Pausar = interromper o instalador mantendo bibliotecas e assets já baixados na pasta do jogo.
 * Ao continuar, o downloader confere o SHA1 de cada arquivo e pula o que já está pronto.
 */
object NeonDownloadManager {
    enum class Status { Queued, Downloading, Paused, Error }

    data class Item(
        val versionId: String,
        val status: Status,
        /** 0..1, ou -1 quando indeterminado */
        val progress: Float = -1f,
        /** bytes por segundo */
        val speedBytes: Long = 0L,
        /** bytes baixados nesta sessão */
        val downloadedBytes: Long = 0L,
        /** tamanho total estimado a partir do progresso (0 = ainda desconhecido) */
        val totalBytesEstimate: Long = 0L,
        val phase: Phase = Phase.Preparing,
        val error: String? = null
    )

    enum class Phase { Preparing, Downloading, Installing }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val lock = Any()

    private val _items = MutableStateFlow<Map<String, Item>>(emptyMap())
    val items: StateFlow<Map<String, Item>> = _items.asStateFlow()

    private val installers = HashMap<String, GameInstaller>()
    private val monitors = HashMap<String, Job>()
    private val queue = ArrayDeque<String>()
    private var activeId: String? = null
    private var appContext: Context? = null

    /** Inicia (ou retoma, se estava pausado / com erro) o download de uma versão. */
    fun start(context: Context, versionId: String) {
        synchronized(lock) {
            appContext = context.applicationContext
            val current = _items.value[versionId]
            if (current != null && (current.status == Status.Downloading || current.status == Status.Queued)) return
            if (VersionsManager.isVersionExists(versionId, checkJson = true)) return
            setItem(Item(versionId = versionId, status = Status.Queued))
            if (versionId !in queue) queue.addLast(versionId)
        }
        pump()
    }

    /** Pausa um download em andamento ou tira da fila um download pendente. */
    fun pause(versionId: String) {
        val wasActive: Boolean
        synchronized(lock) {
            val current = _items.value[versionId] ?: return
            if (current.status != Status.Downloading && current.status != Status.Queued) return
            queue.remove(versionId)
            wasActive = activeId == versionId
            if (wasActive) stopActive(versionId, clearTarget = true)
            setItem(current.copy(status = Status.Paused, speedBytes = 0L))
        }
        if (wasActive) pump()
    }

    /** Cancela e descarta o download (em andamento, na fila, pausado ou com erro). */
    fun cancel(versionId: String) {
        val wasActive: Boolean
        synchronized(lock) {
            if (_items.value[versionId] == null) return
            queue.remove(versionId)
            wasActive = activeId == versionId
            if (wasActive) stopActive(versionId, clearTarget = true)
            _items.update { it - versionId }
        }
        if (wasActive) pump()
    }

    private fun stopActive(versionId: String, clearTarget: Boolean) {
        monitors.remove(versionId)?.cancel()
        installers.remove(versionId)?.cancelInstall(clearTarget = clearTarget)
        if (activeId == versionId) activeId = null
    }

    private fun setItem(item: Item) {
        _items.update { it + (item.versionId to item) }
    }

    private fun pump() {
        val id: String
        val context: Context
        synchronized(lock) {
            if (activeId != null) return
            id = queue.removeFirstOrNull() ?: return
            context = appContext ?: return
            activeId = id
        }
        begin(context, id)
    }

    private fun begin(context: Context, id: String) {
        val installer = GameInstaller(
            context = context,
            info = GameDownloadInfo(gameVersion = id, customVersionName = id),
            scope = scope
        )
        synchronized(lock) {
            installers[id] = installer
            setItem(Item(versionId = id, status = Status.Downloading))
            monitors[id] = scope.launch { monitor(id, installer) }
        }

        installer.installGame(
            onInstalled = { version ->
                finish(id)
                VersionsManager.refresh("NeonDownloadManager.onInstalled", version)
            },
            onError = { th ->
                Logger.warning(TAG, "Failed to install $id", th)
                synchronized(lock) {
                    monitors.remove(id)?.cancel()
                    installers.remove(id)
                    if (activeId == id) activeId = null
                    val current = _items.value[id]
                    if (current != null) {
                        setItem(
                            current.copy(
                                status = Status.Error,
                                speedBytes = 0L,
                                error = th.localizedMessage ?: th.message ?: th::class.java.simpleName
                            )
                        )
                    }
                }
                pump()
            },
            onGameAlreadyInstalled = {
                finish(id)
                VersionsManager.refresh("NeonDownloadManager.alreadyInstalled", id)
            }
        )
    }

    private fun finish(id: String) {
        synchronized(lock) {
            monitors.remove(id)?.cancel()
            installers.remove(id)
            if (activeId == id) activeId = null
            _items.update { it - id }
        }
        pump()
    }

    /** Lê o progresso e a velocidade reais das tarefas do instalador. */
    private suspend fun monitor(id: String, installer: GameInstaller) {
        var downloaded = 0L
        val stepMs = 500L
        while (true) {
            delay(stepMs)
            val tasks = installer.tasksFlow.value
            if (tasks.isEmpty()) continue

            val runningIndex = tasks.indexOfFirst { it.task.stage.value == TaskStage.RUNNING }
            val running = tasks.getOrNull(runningIndex)
            val rate = running?.task?.rateBytesPerSec?.value ?: 0L
            val taskProgress = running?.task?.progress?.value ?: -1f
            val completed = tasks.count { it.task.stage.value == TaskStage.COMPLETED }

            val phase = when {
                runningIndex <= 0 -> Phase.Preparing
                runningIndex >= tasks.lastIndex -> Phase.Installing
                else -> Phase.Downloading
            }
            val progress = when {
                phase == Phase.Downloading && taskProgress >= 0f -> taskProgress
                phase == Phase.Installing -> 0.99f
                else -> (completed.toFloat() / tasks.size).coerceIn(0f, 0.05f)
            }

            if (phase == Phase.Downloading) downloaded += rate * stepMs / 1000L
            val total = if (phase == Phase.Downloading && taskProgress > 0.03f) {
                (downloaded / taskProgress).toLong()
            } else 0L

            _items.update { map ->
                val current = map[id] ?: return@update map
                if (current.status != Status.Downloading) return@update map
                map + (id to current.copy(
                    progress = progress,
                    speedBytes = rate,
                    downloadedBytes = downloaded,
                    totalBytesEstimate = total,
                    phase = phase
                ))
            }
        }
    }
}
