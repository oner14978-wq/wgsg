/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.game.account.auth_server.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface AuthServerDao {
    @Query("SELECT * FROM servers")
    suspend fun getAllServers(): List<AuthServer>

    @Query("SELECT * FROM servers WHERE baseUrl = :baseUrl")
    suspend fun getServer(baseUrl: String): AuthServer?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveServer(server: AuthServer)

    @Delete
    suspend fun deleteServer(server: AuthServer)
}